from flask import Flask, render_template, redirect, request

data = {
    "characters": [
        {
            "card_id": 0,
            "name": "Dummy",
            "tier": 1,
            "tags": ["animal"],
            "attack": 1,
            "health": 1,
            "description": "This is a dummy character",
            "image_base_path": "/images/cards/characters/WizardsFamiliar.webp",
            "location_name": "England",
            "location_coordinates": [0, 0]
        },
        {
            "card_id": 1,
            "name": "Black Cat",
            "tier": 2,
            "tags": ["animal", "evil"],
            "attack": 1,
            "health": 1,
            "description": "",
            "image_base_path": "/images/cards/characters/BlackCat.webp",
            "location_name": "England",
            "location_coordinates": [0, 0]
        },
        {
            "card_id": 2,
            "name": "Lonely Prince",
            "tier": 2,
            "tags": ["good", "prince"],
            "attack": 1,
            "health": 1,
            "image_base_path": "/images/cards/characters/LonelyPrince.webp",
            "description": "When you buy a Princess, I turn into a 5/5 Frog Prince",
            "location_name": "whatever the town the brothers grimm are from",
            "location_coordinates": [10, -3],
        }
    ]
}


# in the real image service, instead need to have an "image_id" parameter for each card
# instead of an "image_base_path", and then send that "image_id" to your image service, which
# will send back the image_url
def get_image_service_path(image_base_path):
    return "https://brawlcards.com" + image_base_path


def get_location_picture(location_coordinates):
    # in actuality, will need to use classmate's location service,
    # sending the coordinates or the name or something
    # dummy data
    return "https://www.thediscoveriesof.com/wp-content/uploads/2017/05/Cool-Places-in-Singapore-Gardens-by-the-Bay-.jpg"


def post_process_card(card):
    card["tags_list_str"] = ', '.join(card['tags'])

    # query the google places API thing giving the location coordinates
    card["location_coordinates_list_str"] = ', '.join(str(x) for x in card['location_coordinates'])
    card["location_picture"] = get_location_picture(card["location_coordinates"])
    card["image_url"] = get_image_service_path(card["image_base_path"])

    return card


def post_process_cards(cards):
    return [post_process_card(card) for card in cards]


def find_character_by_id(card_id):
    """
    results = []
    for x in data["characters"]
        if x[card_id] == card_id:
            results.append(x)

    return results

    SELECT * FROM characters WHERE card_id=?
    """

    return [x for x in data["characters"] if x["card_id"] == card_id]


def find_character_by_name(name):
    return [x for x in data["characters"] if x["name"] == name]


def find_character_by_tier(tier):
    return [x for x in data["characters"] if x["tier"] == tier]


def find_characters_by_tag(tag):
    return [x for x in data["characters"] if tag in x["tags"]]


def edit_character_by_id(card_id, new_values):
    """
    UPDATE characters
    WHERE card_id = ?
    SET name = ?, tier = ?, ...
    """

    results = find_character_by_id(card_id)
    old_card = results[0]
    for field_name, field_value in new_values.items():
        old_card[field_name] = field_value


app = Flask('app')


@app.route('/')
def index():
    return redirect('/characters', 302)


@app.route('/characters', methods=['GET', 'POST'])
def find_characters():
    """
    Show a list of the character cards in a GET request
    URL looks like this! http://127.0.0.1:8080/characters
    """

    tier_query = request.form.get('tier')
    if not tier_query:
        results = data["characters"]
    else:
        results = find_character_by_tier(int(tier_query))

    return render_template('results.html', results=results)


@app.route('/character/<card_id_str>', methods=['GET'])
def show_character(card_id_str):
    """
    Show the page and all the data for a specific character.
    :return:
    """

    card_id = int(card_id_str)
    results = post_process_cards(find_character_by_id(card_id))
    if len(results) == 0:
        character = {}
    else:
        character = results[0]

    return render_template('character.html', data=character)


@app.route('/edit_character', methods=['POST'])
def edit_character():
    """
    Show the page and all the data for a specific character.
    :return:
    """

    card_id = int(request.form.get('card_id'))

    tag_str = request.form["tags"]
    tag_str = tag_str.replace(' ', '')
    tags = tag_str.split(',')

    loc_coords_str = request.form["location_coordinates"]
    loc_coords_str = loc_coords_str.replace(' ', '')
    loc_coords_list = loc_coords_str.split(',')
    loc_coords = [int(x) for x in loc_coords_list]

    card_data = {
        "card_id": card_id,
        "name": request.form["name"],
        "tier": int(request.form["tier"]),
        "tags": tags,
        "attack": int(request.form["attack"]),
        "health": int(request.form["health"]),
        "description": request.form["description"],
        "location_name": request.form["location_name"],
        "location_coordinates": loc_coords
    }

    edit_character_by_id(card_id, card_data)
    return redirect('/character/' + str(card_id), 302)


app.run(host='127.0.0.1', port=8080, debug=True)
